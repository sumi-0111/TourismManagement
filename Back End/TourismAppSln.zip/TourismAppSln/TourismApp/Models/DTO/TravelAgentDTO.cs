﻿namespace TourismApp.Models.DTO
{
    public class TravelAgentDTO:TravelAgent
    {
        public string PasswordClear { get; set; }
    }
}
